-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: i6a504.p.ssafy.io    Database: barrierfree
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alarm`
--

DROP TABLE IF EXISTS `alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alarm` (
  `alarm_seq` bigint NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `alarm_type` varchar(1) NOT NULL,
  `alarm_data` bigint NOT NULL,
  `check_yn` varchar(1) NOT NULL DEFAULT 'n',
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(20) NOT NULL,
  PRIMARY KEY (`alarm_seq`),
  KEY `alarm_user_fk_idx` (`user_seq`),
  CONSTRAINT `alarm_user_fk` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alarm`
--

LOCK TABLES `alarm` WRITE;
/*!40000 ALTER TABLE `alarm` DISABLE KEYS */;
INSERT INTO `alarm` VALUES (1,1,'0',1,'y','n','2022-02-17 09:04:42','1','2022-02-17 18:09:20','yminsang96'),(2,1,'0',3,'y','n','2022-02-17 09:08:27','1','2022-02-17 18:09:18','yminsang96'),(3,1,'0',2,'n','n','2022-02-17 09:08:29','1','2022-02-17 09:08:29','1'),(4,1,'0',4,'y','n','2022-02-17 09:08:30','1','2022-02-17 18:09:04','yminsang96'),(5,1,'0',5,'y','n','2022-02-17 09:08:31','1','2022-02-17 18:09:07','yminsang96'),(6,1,'1',10,'y','n','2022-02-17 19:36:57','yminsang96','2022-02-17 19:44:55','yminsang96'),(7,1,'1',10,'y','n','2022-02-17 19:37:27','yminsang96','2022-02-17 19:44:45','yminsang96'),(8,1,'1',13,'n','n','2022-02-17 19:39:37','yminsang96','2022-02-17 19:39:37','yminsang96'),(9,1,'1',13,'n','n','2022-02-17 19:45:30','yminsang96','2022-02-17 19:45:30','yminsang96'),(10,1,'1',3,'y','n','2022-02-17 19:47:00','yminsang96','2022-02-17 19:54:37','yminsang96'),(11,4,'1',54,'n','n','2022-02-17 20:03:10','sdi1358','2022-02-17 20:03:10','sdi1358'),(12,1,'1',3,'y','n','2022-02-17 20:10:46','yminsang96','2022-02-17 20:11:08','yminsang96'),(13,1,'1',3,'y','n','2022-02-17 20:10:57','yminsang96','2022-02-17 20:11:05','yminsang96'),(14,1,'1',3,'y','n','2022-02-17 20:15:07','yminsang96','2022-02-17 20:15:19','yminsang96'),(15,1,'1',3,'y','n','2022-02-17 20:19:57','yminsang96','2022-02-17 20:28:41','yminsang96');
/*!40000 ALTER TABLE `alarm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18  3:38:19
