-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: i6a504.p.ssafy.io    Database: barrierfree
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) NOT NULL,
  `user_nickname` varchar(8) NOT NULL,
  `user_pwd` varchar(100) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `user_role` varchar(1) NOT NULL DEFAULT '0',
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(20) NOT NULL,
  `enabled_yn` varchar(1) NOT NULL DEFAULT 'n',
  `cert_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `user_nickname` (`user_nickname`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'yminsang96','민상','$2a$10$zjDaVI4PtSJ9N3ztiSsoGebIxXDzoYRLXU8..nP5o2nGZUqdz7CBS','yminsang96@gmail.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 14:49:59','yminsang96','2022-02-18 02:42:29','yminsang96','y','IPAOIkGj0P'),(3,'jung55120','쫑이','$2a$10$..1n.Z1iE7MkT1U6U.H0V.HxRYeyQPP1KY0hc8qQWFQR9pugA.ECW','jung55120@naver.com','/images/20220217_4ae9374b-efe8-4569-b734-2607495f4592_증명사진.png','0','n','2022-02-17 15:00:51','jung55120','2022-02-17 17:13:45','jung55120','y','znYNM8ln27'),(4,'sdi1358','헝아','$2a$10$QDeUSQ7yEpzuhxDHKQrMCeRNgsFwTHsesb.u6gwPSUyCu3jfQGi7e','sdi1358_@naver.com','/images/20220217_473965ad-0745-4af8-8488-de15c75ccc97_IMG_3304.jpg','0','n','2022-02-17 15:19:43','sdi135','2022-02-17 16:32:08','sdi1358','y',NULL),(5,'hsooj','pang','$2a$10$2OBN9gOH7/EjGuEOfUIeOuSVIAjf2jAnpFEOUJJLDe7fdJE4nzljy','blue8959@naver.com','/images/20220217_048c9c90-c698-40af-9720-859d8e6f99ec_alin.png','0','n','2022-02-17 15:33:19','hsooj','2022-02-17 16:30:26','hsooj','y','WDg5cVzGyn'),(6,'hyun55120','서울여행자','$2a$10$Q4oT68mX7jYb1ERmg4QZ5.RL/UDf/Y74a9b5p/yZX5qU14SpRXXiy','hyun55120@gmail.com','/images/20220217_cd3e6c5d-c2f5-4dae-981a-55e0385d71e0_IMG_3319.jfif','0','n','2022-02-17 16:17:51','hyun55120','2022-02-17 16:29:02','hyun55120','y','47smDhHR7s'),(7,'string','string','$2a$10$CqP1xe9t/7Wvw5oqQKlE...RK/eLEDQSAk2LuZH6WEG6WaXnE1mqm','string','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 16:38:20','string','2022-02-17 16:38:20','string','y','u7EfQed4yB'),(8,'consultunt','컨설턴트님','$2a$10$ptYYvHrJKx1LWWFoCWOANuS6R7xqrL7lXTcNuuA.TTqgL.xcKX6JC','weclusive@gmail.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 19:23:03','consultunt','2022-02-17 19:23:03','consultunt','y','jv2r48gEyW'),(9,'coach','코치님','$2a$10$w.h3g3QyU4JyYU9e7/orXuTZdALLHbjOuHUUJ4xIb4HqCKNg/pXpi','weclu1sive@gmail.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 19:23:55','coach','2022-02-17 19:23:55','coach','y','VHJTYJg7jf'),(10,'mnem123','mnem123','$2a$10$baJxg3hj.oh7BDd6YoJrH.74dHZIr6.SdYTNnOr6fEnpb7Ja3mnhW','dkdltm213@naver.com','/images/20220217_2e246cf3-a0bd-4e95-958b-62b891718492_바다 프로필.jpg','0','n','2022-02-17 19:43:15','mnem123','2022-02-17 19:45:37','mnem123','y','MQQswNHFBg'),(11,'ssafy123','싸피굿','$2a$10$9BcaW41I6fXW0Tw1kQJtAeYfogN9WPHhxYOrcuMNoqBci6R6nInFW','ssafy123@naver.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 20:07:36','ssafy123','2022-02-17 20:07:36','ssafy123','n','s4VNmst1B2'),(12,'ssafy132','ssafy132','$2a$10$93uYZ90x4Je6Tbp5xhsSleLpvnWVdcQik4yfs4oQU.pcZQzh2xlWO','ssafy@ruu.kr','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 20:09:16','ssafy132','2022-02-17 20:09:16','ssafy132','y','dg38R27ROk'),(13,'snowman','snowman','$2a$10$/0rJ0Zzg.EjgXC7/dS85LuPN32gI5ORuLMFHI30RSEWtfJQymS846','yoonsoonho92@naver.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 21:17:04','snowman','2022-02-17 21:17:04','snowman','y','NzdVHUNM0W'),(14,'zico_rayon','고향서울','$2a$10$oG9LGN2IOU2cEpFD8XwgcuTMrswnujC4WUtQG4KhktjMw6fZWk15m','zico_rayon@daum.net','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-17 21:50:29','zico_rayon','2022-02-17 21:50:29','zico_rayon','y','lgqApRfoTW'),(15,'barrierfree','B_F','$2a$10$DuP2Ph.08sM5/6XKvAGCPOosqqOmD4F7XHSyV90WooKjOX9Nvsfby','blue8957@gmail.com','/images/20220217_1c47e3d9-0ac1-4e0d-acea-e0d134bce994_basic_profile.jpg','0','n','2022-02-18 00:09:33','barrierfree','2022-02-18 00:09:33','barrierfree','n','Y5UalnYDNW'),(16,'pang_sj','pang_hsj','$2a$10$37.Ujkw8lApFV0fhA84BSe50xmTRl0poMeNcZYquGzjF3Qp8mQY4S','hsooj@kakao.com','/images/20220218_d33d53ab-6c82-47be-a677-47c53fe88b04_help.jpg','0','n','2022-02-18 01:06:09','pang_sj','2022-02-18 03:15:51','pang_sj','y',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18  3:38:23
