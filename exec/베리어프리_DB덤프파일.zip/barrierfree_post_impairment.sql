-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: i6a504.p.ssafy.io    Database: barrierfree
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post_impairment`
--

DROP TABLE IF EXISTS `post_impairment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_impairment` (
  `pi_seq` bigint NOT NULL AUTO_INCREMENT,
  `post_seq` bigint NOT NULL,
  `code` varchar(15) NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(20) NOT NULL,
  PRIMARY KEY (`pi_seq`),
  KEY `post_impairment_post_fk` (`post_seq`),
  KEY `post_impairment_common_code_fk` (`code`),
  CONSTRAINT `post_impairment_common_code_fk` FOREIGN KEY (`code`) REFERENCES `common_code` (`code`),
  CONSTRAINT `post_impairment_post_fk` FOREIGN KEY (`post_seq`) REFERENCES `post` (`post_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_impairment`
--

LOCK TABLES `post_impairment` WRITE;
/*!40000 ALTER TABLE `post_impairment` DISABLE KEYS */;
INSERT INTO `post_impairment` VALUES (1,1,'physical','n','2022-02-17 15:01:24','yminsang96','2022-02-17 15:01:24','yminsang96'),(2,2,'visibility','n','2022-02-17 15:02:05','jung55120','2022-02-17 15:02:05','jung55120'),(3,3,'physical','n','2022-02-17 15:35:54','yminsang96','2022-02-17 15:35:54','yminsang96'),(4,4,'physical','n','2022-02-17 15:41:06','yminsang96','2022-02-17 15:41:06','yminsang96'),(5,6,'visibility','n','2022-02-17 15:43:56','jung55120','2022-02-17 15:43:56','jung55120'),(6,7,'physical','n','2022-02-17 15:47:53','hsooj','2022-02-17 15:47:53','hsooj'),(7,7,'senior','n','2022-02-17 15:47:53','hsooj','2022-02-17 15:47:53','hsooj'),(8,8,'physical','n','2022-02-17 15:48:04','jung55120','2022-02-17 15:48:04','jung55120'),(9,9,'physical','n','2022-02-17 15:49:01','hsooj','2022-02-17 15:49:01','hsooj'),(10,9,'infant','n','2022-02-17 15:49:01','hsooj','2022-02-17 15:49:01','hsooj'),(11,9,'senior','n','2022-02-17 15:49:01','hsooj','2022-02-17 15:49:01','hsooj'),(12,10,'physical','n','2022-02-17 15:50:10','yminsang96','2022-02-17 15:50:10','yminsang96'),(13,11,'visibility','n','2022-02-17 15:50:42','jung55120','2022-02-17 15:50:42','jung55120'),(14,13,'infant','n','2022-02-17 15:51:41','yminsang96','2022-02-17 15:51:41','yminsang96'),(15,13,'senior','n','2022-02-17 15:51:41','yminsang96','2022-02-17 15:51:41','yminsang96'),(16,14,'physical','n','2022-02-17 15:54:13','hsooj','2022-02-17 15:54:13','hsooj'),(17,14,'infant','n','2022-02-17 15:54:13','hsooj','2022-02-17 15:54:13','hsooj'),(18,14,'senior','n','2022-02-17 15:54:13','hsooj','2022-02-17 15:54:13','hsooj'),(19,15,'visibility','n','2022-02-17 15:56:34','jung55120','2022-02-17 15:56:34','jung55120'),(20,16,'physical','n','2022-02-17 16:10:14','yminsang96','2022-02-17 16:10:14','yminsang96'),(21,17,'physical','n','2022-02-17 16:15:16','yminsang96','2022-02-17 16:15:16','yminsang96'),(22,18,'physical','n','2022-02-17 16:21:24','yminsang96','2022-02-17 16:21:24','yminsang96'),(23,19,'physical','n','2022-02-17 16:21:44','hyun55120','2022-02-17 16:21:44','hyun55120'),(24,21,'physical','n','2022-02-17 16:24:13','yminsang96','2022-02-17 16:24:13','yminsang96'),(25,22,'physical','n','2022-02-17 16:28:28','hyun55120','2022-02-17 16:28:28','hyun55120'),(26,23,'physical','n','2022-02-17 16:32:33','yminsang96','2022-02-17 16:32:33','yminsang96'),(27,24,'physical','n','2022-02-17 16:32:59','yminsang96','2022-02-17 16:32:59','yminsang96'),(28,25,'physical','n','2022-02-17 16:33:45','yminsang96','2022-02-17 16:33:45','yminsang96'),(29,26,'physical','n','2022-02-17 16:41:07','yminsang96','2022-02-17 16:41:07','yminsang96'),(30,27,'physical','n','2022-02-17 16:44:04','yminsang96','2022-02-17 16:44:04','yminsang96'),(31,28,'physical','n','2022-02-17 16:44:52','yminsang96','2022-02-17 16:44:52','yminsang96'),(32,29,'physical','n','2022-02-17 16:50:46','yminsang96','2022-02-17 16:50:46','yminsang96'),(33,30,'physical','n','2022-02-17 16:59:26','yminsang96','2022-02-17 16:59:26','yminsang96'),(34,31,'physical','n','2022-02-17 17:01:44','yminsang96','2022-02-17 17:01:44','yminsang96'),(35,32,'physical','n','2022-02-17 17:01:45','hyun55120','2022-02-17 17:01:45','hyun55120'),(36,33,'physical','n','2022-02-17 17:05:49','hyun55120','2022-02-17 17:05:49','hyun55120'),(37,34,'physical','n','2022-02-17 17:08:53','yminsang96','2022-02-17 17:08:53','yminsang96'),(38,35,'deaf','n','2022-02-17 17:10:20','hyun55120','2022-02-17 17:10:20','hyun55120'),(39,35,'infant','n','2022-02-17 17:10:20','hyun55120','2022-02-17 17:10:20','hyun55120'),(40,36,'physical','n','2022-02-17 17:14:30','jung55120','2022-02-17 17:14:30','jung55120'),(41,36,'deaf','n','2022-02-17 17:14:30','jung55120','2022-02-17 17:14:30','jung55120'),(42,37,'physical','n','2022-02-17 17:15:13','jung55120','2022-02-17 17:15:13','jung55120'),(43,37,'visibility','n','2022-02-17 17:15:13','jung55120','2022-02-17 17:15:13','jung55120'),(44,37,'senior','n','2022-02-17 17:15:13','jung55120','2022-02-17 17:15:13','jung55120'),(45,38,'physical','n','2022-02-17 17:35:10','sdi1358','2022-02-17 17:35:10','sdi1358'),(46,39,'physical','n','2022-02-17 17:37:20','yminsang96','2022-02-17 17:37:20','yminsang96'),(47,40,'physical','n','2022-02-17 17:38:54','yminsang96','2022-02-17 17:38:54','yminsang96'),(48,41,'physical','n','2022-02-17 17:39:14','sdi1358','2022-02-17 17:39:14','sdi1358'),(49,42,'physical','n','2022-02-17 17:43:18','yminsang96','2022-02-17 17:43:18','yminsang96'),(50,43,'physical','n','2022-02-17 17:51:04','yminsang96','2022-02-17 17:51:04','yminsang96'),(51,44,'physical','n','2022-02-17 17:52:01','yminsang96','2022-02-17 17:52:01','yminsang96'),(52,45,'physical','n','2022-02-17 17:52:37','yminsang96','2022-02-17 17:52:37','yminsang96'),(53,46,'physical','n','2022-02-17 18:45:10','hsooj','2022-02-17 18:45:10','hsooj'),(54,46,'infant','n','2022-02-17 18:45:10','hsooj','2022-02-17 18:45:10','hsooj'),(55,46,'visibility','n','2022-02-17 18:45:10','hsooj','2022-02-17 18:45:10','hsooj'),(56,46,'senior','n','2022-02-17 18:45:10','hsooj','2022-02-17 18:45:10','hsooj'),(57,47,'infant','n','2022-02-17 18:55:40','hsooj','2022-02-17 18:55:40','hsooj'),(58,48,'infant','n','2022-02-17 19:02:19','hsooj','2022-02-17 19:02:19','hsooj'),(59,48,'senior','n','2022-02-17 19:02:19','hsooj','2022-02-17 19:02:19','hsooj'),(60,49,'physical','n','2022-02-17 19:14:01','hsooj','2022-02-17 19:14:01','hsooj'),(61,49,'deaf','n','2022-02-17 19:14:01','hsooj','2022-02-17 19:14:01','hsooj'),(62,49,'infant','n','2022-02-17 19:14:01','hsooj','2022-02-17 19:14:01','hsooj'),(63,49,'visibility','n','2022-02-17 19:14:01','hsooj','2022-02-17 19:14:01','hsooj'),(64,49,'senior','n','2022-02-17 19:14:01','hsooj','2022-02-17 19:14:01','hsooj'),(65,52,'infant','n','2022-02-17 19:45:21','hsooj','2022-02-17 19:45:21','hsooj'),(66,53,'visibility','n','2022-02-17 19:49:01','mnem123','2022-02-17 19:49:01','mnem123'),(67,54,'physical','n','2022-02-17 20:00:52','sdi1358','2022-02-17 20:00:52','sdi1358'),(68,54,'senior','n','2022-02-17 20:00:52','sdi1358','2022-02-17 20:00:52','sdi1358'),(69,55,'physical','n','2022-02-17 20:05:04','yminsang96','2022-02-17 20:05:04','yminsang96'),(70,56,'physical','n','2022-02-17 20:14:51','sdi1358','2022-02-17 20:14:51','sdi1358'),(71,56,'senior','n','2022-02-17 20:14:51','sdi1358','2022-02-17 20:14:51','sdi1358'),(72,57,'infant','n','2022-02-17 21:18:15','hsooj','2022-02-17 21:18:15','hsooj'),(73,57,'visibility','n','2022-02-17 21:18:15','hsooj','2022-02-17 21:18:15','hsooj'),(74,57,'senior','n','2022-02-17 21:18:15','hsooj','2022-02-17 21:18:15','hsooj'),(75,59,'physical','n','2022-02-17 21:43:54','snowman','2022-02-17 21:43:54','snowman'),(76,59,'deaf','n','2022-02-17 21:43:54','snowman','2022-02-17 21:43:54','snowman'),(77,60,'physical','n','2022-02-17 21:48:49','snowman','2022-02-17 21:48:49','snowman'),(78,60,'deaf','n','2022-02-17 21:48:49','snowman','2022-02-17 21:48:49','snowman'),(79,61,'physical','n','2022-02-17 22:04:16','snowman','2022-02-17 22:04:16','snowman'),(80,61,'deaf','n','2022-02-17 22:04:16','snowman','2022-02-17 22:04:16','snowman'),(81,62,'physical','n','2022-02-17 22:11:32','snowman','2022-02-17 22:11:32','snowman'),(82,62,'deaf','n','2022-02-17 22:11:32','snowman','2022-02-17 22:11:32','snowman'),(83,64,'physical','n','2022-02-17 22:36:20','snowman','2022-02-17 22:36:20','snowman'),(84,64,'deaf','n','2022-02-17 22:36:20','snowman','2022-02-17 22:36:20','snowman'),(85,65,'physical','n','2022-02-17 22:46:37','snowman','2022-02-17 22:46:37','snowman'),(86,65,'deaf','n','2022-02-17 22:46:37','snowman','2022-02-17 22:46:37','snowman'),(87,66,'physical','n','2022-02-17 22:56:13','snowman','2022-02-17 22:56:13','snowman'),(88,66,'deaf','n','2022-02-17 22:56:13','snowman','2022-02-17 22:56:13','snowman'),(89,67,'physical','n','2022-02-17 23:44:20','yminsang96','2022-02-17 23:44:20','yminsang96'),(90,68,'physical','n','2022-02-18 01:21:27','sdi1358','2022-02-18 01:21:27','sdi1358'),(91,68,'visibility','n','2022-02-18 01:21:27','sdi1358','2022-02-18 01:21:27','sdi1358'),(92,69,'visibility','n','2022-02-18 01:30:26','sdi1358','2022-02-18 01:30:26','sdi1358'),(93,71,'physical','n','2022-02-18 01:48:32','sdi1358','2022-02-18 01:48:32','sdi1358'),(94,71,'deaf','n','2022-02-18 01:48:32','sdi1358','2022-02-18 01:48:32','sdi1358'),(95,71,'infant','n','2022-02-18 01:48:32','sdi1358','2022-02-18 01:48:32','sdi1358'),(96,71,'visibility','n','2022-02-18 01:48:32','sdi1358','2022-02-18 01:48:32','sdi1358'),(97,71,'senior','n','2022-02-18 01:48:32','sdi1358','2022-02-18 01:48:32','sdi1358'),(98,70,'physical','n','2022-02-18 02:07:19','pang_sj','2022-02-18 02:07:19','pang_sj'),(99,70,'deaf','n','2022-02-18 02:07:19','pang_sj','2022-02-18 02:07:19','pang_sj'),(100,70,'infant','n','2022-02-18 02:07:19','pang_sj','2022-02-18 02:07:19','pang_sj'),(101,74,'physical','n','2022-02-18 02:21:45','sdi1358','2022-02-18 02:21:45','sdi1358'),(102,74,'infant','n','2022-02-18 02:21:45','sdi1358','2022-02-18 02:21:45','sdi1358');
/*!40000 ALTER TABLE `post_impairment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18  3:38:22
