-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: i6a504.p.ssafy.io    Database: barrierfree
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `scrap`
--

DROP TABLE IF EXISTS `scrap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scrap` (
  `scrap_seq` bigint NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `scrap_type` varchar(1) NOT NULL,
  `scrap_data` bigint NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(20) NOT NULL,
  PRIMARY KEY (`scrap_seq`),
  KEY `scrap_user_fk_idx` (`user_seq`),
  CONSTRAINT `scrap_user_fk` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scrap`
--

LOCK TABLES `scrap` WRITE;
/*!40000 ALTER TABLE `scrap` DISABLE KEYS */;
INSERT INTO `scrap` VALUES (1,3,'0',1,'n','2022-02-17 15:02:36','jung55120','2022-02-17 15:02:36','jung55120'),(5,3,'0',8,'n','2022-02-17 15:48:29','jung55120','2022-02-17 15:48:29','jung55120'),(6,6,'0',22,'n','2022-02-17 16:29:28','hyun55120','2022-02-17 16:29:28','hyun55120'),(8,4,'0',22,'n','2022-02-17 16:29:45','sdi1358','2022-02-17 16:29:45','sdi1358'),(9,5,'0',22,'n','2022-02-17 16:30:45','hsooj','2022-02-17 16:30:45','hsooj'),(15,9,'0',3,'y','2022-02-17 19:24:52','coach','2022-02-17 19:26:48','coach'),(16,9,'0',3,'y','2022-02-17 19:26:49','coach','2022-02-17 20:10:33','coach'),(24,8,'0',3,'y','2022-02-17 19:47:00','consultunt','2022-02-17 19:49:14','consultunt'),(25,10,'0',54,'n','2022-02-17 20:03:10','mnem123','2022-02-17 20:03:10','mnem123'),(26,9,'0',3,'y','2022-02-17 20:10:46','coach','2022-02-17 20:10:54','coach'),(27,9,'0',3,'y','2022-02-17 20:10:57','coach','2022-02-17 20:14:41','coach'),(28,9,'0',3,'y','2022-02-17 20:15:07','coach','2022-02-17 20:19:56','coach'),(29,9,'0',3,'y','2022-02-17 20:19:57','coach','2022-02-18 01:25:16','coach'),(30,6,'0',53,'n','2022-02-17 20:25:32','hyun55120','2022-02-17 20:25:32','hyun55120'),(33,3,'1',591866,'n','2022-02-17 21:21:34','jung55120','2022-02-17 21:21:34','jung55120'),(34,13,'0',59,'n','2022-02-17 22:04:54','snowman','2022-02-17 22:04:54','snowman'),(35,13,'0',60,'n','2022-02-17 22:04:56','snowman','2022-02-17 22:04:56','snowman'),(36,13,'0',61,'n','2022-02-17 22:04:57','snowman','2022-02-17 22:04:57','snowman'),(37,13,'0',53,'n','2022-02-17 22:05:02','snowman','2022-02-17 22:05:02','snowman'),(38,13,'0',33,'n','2022-02-17 22:05:15','snowman','2022-02-17 22:05:15','snowman'),(39,13,'0',32,'n','2022-02-17 22:05:17','snowman','2022-02-17 22:05:17','snowman'),(40,5,'0',60,'n','2022-02-17 22:19:58','hsooj','2022-02-17 22:19:58','hsooj'),(41,14,'0',46,'n','2022-02-17 22:55:56','zico_rayon','2022-02-17 22:55:56','zico_rayon'),(45,10,'0',73,'n','2022-02-18 02:40:28','mnem123','2022-02-18 02:40:28','mnem123'),(46,10,'0',69,'n','2022-02-18 02:40:30','mnem123','2022-02-18 02:40:30','mnem123'),(47,4,'1',591866,'n','2022-02-18 02:40:32','sdi1358','2022-02-18 02:40:32','sdi1358'),(48,10,'1',126131,'n','2022-02-18 02:41:16','mnem123','2022-02-18 02:41:16','mnem123'),(49,10,'1',1614282,'n','2022-02-18 02:41:18','mnem123','2022-02-18 02:41:18','mnem123'),(50,16,'1',749216,'n','2022-02-18 02:41:36','pang_sj','2022-02-18 02:41:36','pang_sj'),(51,16,'0',67,'n','2022-02-18 02:42:26','pang_sj','2022-02-18 02:42:26','pang_sj'),(52,16,'0',3,'n','2022-02-18 02:42:28','pang_sj','2022-02-18 02:42:28','pang_sj'),(53,1,'0',73,'n','2022-02-18 02:47:31','yminsang96','2022-02-18 02:47:31','yminsang96'),(54,1,'1',129437,'n','2022-02-18 02:47:41','yminsang96','2022-02-18 02:47:41','yminsang96'),(55,16,'1',126521,'y','2022-02-18 02:48:44','pang_sj','2022-02-18 02:48:45','pang_sj'),(56,1,'0',71,'y','2022-02-18 02:49:25','yminsang96','2022-02-18 02:50:38','yminsang96'),(57,1,'0',65,'y','2022-02-18 02:49:26','yminsang96','2022-02-18 02:50:37','yminsang96'),(58,1,'0',64,'y','2022-02-18 02:49:27','yminsang96','2022-02-18 02:50:36','yminsang96'),(59,1,'0',60,'y','2022-02-18 02:49:28','yminsang96','2022-02-18 02:50:18','yminsang96'),(60,1,'0',61,'y','2022-02-18 02:49:29','yminsang96','2022-02-18 02:50:47','yminsang96'),(61,1,'0',62,'y','2022-02-18 02:49:30','yminsang96','2022-02-18 02:50:28','yminsang96'),(62,1,'0',59,'y','2022-02-18 02:49:40','yminsang96','2022-02-18 02:50:25','yminsang96'),(63,1,'0',58,'y','2022-02-18 02:49:41','yminsang96','2022-02-18 02:50:16','yminsang96'),(64,1,'0',38,'y','2022-02-18 02:49:46','yminsang96','2022-02-18 02:50:13','yminsang96'),(65,1,'0',41,'y','2022-02-18 02:49:47','yminsang96','2022-02-18 02:50:12','yminsang96'),(66,1,'0',46,'y','2022-02-18 02:49:49','yminsang96','2022-02-18 02:50:33','yminsang96'),(67,1,'0',47,'y','2022-02-18 02:49:50','yminsang96','2022-02-18 02:50:09','yminsang96'),(68,1,'0',22,'n','2022-02-18 02:49:59','yminsang96','2022-02-18 02:49:59','yminsang96'),(69,1,'1',591866,'n','2022-02-18 02:50:00','yminsang96','2022-02-18 02:50:00','yminsang96');
/*!40000 ALTER TABLE `scrap` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18  3:38:23
