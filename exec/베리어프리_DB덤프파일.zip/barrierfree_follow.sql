-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: i6a504.p.ssafy.io    Database: barrierfree
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `follow`
--

DROP TABLE IF EXISTS `follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow` (
  `follow_seq` bigint NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `following_seq` int NOT NULL,
  `del_yn` varchar(1) NOT NULL DEFAULT 'n',
  `reg_dt` varchar(20) NOT NULL,
  `reg_id` varchar(20) NOT NULL,
  `mod_dt` varchar(20) NOT NULL,
  `mod_id` varchar(20) NOT NULL,
  PRIMARY KEY (`follow_seq`),
  KEY `follow_user_seq_fk_idx` (`user_seq`),
  KEY `follow_user_following_seq_fk_idx` (`following_seq`),
  CONSTRAINT `follow_user_following_seq_fk` FOREIGN KEY (`following_seq`) REFERENCES `user` (`user_seq`),
  CONSTRAINT `follow_user_user_seq_fk` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow`
--

LOCK TABLES `follow` WRITE;
/*!40000 ALTER TABLE `follow` DISABLE KEYS */;
INSERT INTO `follow` VALUES (1,5,4,'n','2022-02-17 17:56:43','hsooj','2022-02-17 17:56:43','hsooj'),(2,1,4,'n','2022-02-17 17:56:53','yminsang96','2022-02-17 17:56:53','yminsang96'),(3,1,10,'n','2022-02-17 20:05:12','yminsang96','2022-02-17 20:05:12','yminsang96'),(4,3,6,'n','2022-02-17 20:15:10','jung55120','2022-02-17 20:15:10','jung55120'),(5,9,1,'y','2022-02-17 20:28:52','coach','2022-02-18 01:25:14','coach'),(6,10,1,'y','2022-02-17 21:17:01','mnem123','2022-02-17 21:17:11','mnem123'),(7,4,6,'n','2022-02-18 01:20:29','sdi1358','2022-02-18 01:20:29','sdi1358'),(8,4,1,'n','2022-02-18 01:52:03','sdi1358','2022-02-18 01:52:03','sdi1358'),(9,4,5,'n','2022-02-18 01:52:04','sdi1358','2022-02-18 01:52:04','sdi1358'),(10,4,10,'n','2022-02-18 01:52:14','sdi1358','2022-02-18 01:52:14','sdi1358'),(11,1,6,'n','2022-02-18 02:22:11','yminsang96','2022-02-18 02:22:11','yminsang96'),(12,10,1,'n','2022-02-18 02:41:02','mnem123','2022-02-18 02:41:02','mnem123'),(13,10,4,'n','2022-02-18 02:41:03','mnem123','2022-02-18 02:41:03','mnem123'),(14,16,1,'n','2022-02-18 02:45:43','pang_sj','2022-02-18 02:45:43','pang_sj'),(15,16,6,'n','2022-02-18 02:46:04','pang_sj','2022-02-18 02:46:04','pang_sj');
/*!40000 ALTER TABLE `follow` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18  3:38:25
